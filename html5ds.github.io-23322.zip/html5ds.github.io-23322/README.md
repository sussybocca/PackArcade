Game Play Color
===============

A JavaScript Game Boy Color emulator for iOS, based on the [GameBoy-Online](https://github.com/taisel/GameBoy-Online) emulator core.

Modified by EXTraNooBeD on 2016.

More Information is Developing...
===============
